"""
Subcontroller module for Froggit

This module contains the subcontroller to manage a single level in the Froggit game.
Instances of Level represent a single game, read from a JSON.  Whenever you load a new
level, you are expected to make a new instance of this class.

The subcontroller Level manages the frog and all of the obstacles. However, those are
all defined in models.py.  The only thing in this class is the level class and all of
the individual lanes.

This module should not contain any more classes than Levels. If you need a new class,
it should either go in the lanes.py module or the models.py module.

# Katie (Erqi) Zhou, ez224
# Dec 21, 2020
"""
from game2d import *
from consts import *
from lanes  import *
from models import *

# PRIMARY RULE: Level can only access attributes in models.py or lanes.py using getters
# and setters. Level is NOT allowed to access anything in app.py (Subcontrollers are not
# permitted to access anything in their parent. To see why, take CS 3152)


class Level(object):
    """
    This class controls a single level of Froggit.

    This subcontroller has a reference to the frog and the individual lanes.  However,
    it does not directly store any information about the contents of a lane (e.g. the
    cars, logs, or other items in each lane). That information is stored inside of the
    individual lane objects.

    If you want to pause the game, tell this controller to draw, but do not update.  See
    subcontrollers.py from Lesson 27 for an example.  This class will be similar to that
    one in many ways.

    All attributes of this class are to be hidden.  No attribute should be accessed
    without going through a getter/setter first.  However, just because you have an
    attribute does not mean that you have to have a getter for it.  For example, the
    Froggit app probably never needs to access the attribute for the Frog object, so
    there is no need for a getter.

    The one thing you DO need a getter for is the width and height.  The width and height
    of a level is different than the default width and height and the window needs to
    resize to match.  That resizing is done in the Froggit app, and so it needs to access
    these values in the level.  The height value should include one extra grid square
    to suppose the number of lives meter.
    """
    # LIST ALL HIDDEN ATTRIBUTES HERE
    # Attribute:_frog1
    # Invariant:_frog1 is a frog object and a copy of the original frog.
    #
    # Attribute:_lives
    # Invariant:_lives is a list of images that represents the remaning lives.
    #
    # Attribute:_frogwin
    # Invariant:_frogwin is a bool representing the frog has win or not.
    #
    # Attribute:_xi
    # Invariant:_xi is an int or float representing the initial x position
    #
    # Attribute:_yi
    # Invariant:_yi is an int or float representing the initial y position
    #
    # Attribute:_livecount
    # Invariant:_livecount is a GLabel object that shows the lives
    #
    # Attribute:_animator
    # Invariant:_animator is a generator that animates the frog's movement.
    #
    # Attribute:_jumpsound
    # Invariant:_jumpsound is a sound object that sends out the sound of a jump.
    #
    # Attribute:_trillsound
    # Invariant:_trillsound is a sound object that sends out the sound of winning.
    #
    # Attribute:_splatsound
    # Invariant:_splatsound is a sound object that sends out the sound of dying.

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getFrogInitial(self, width, hitboxjson):
        """
        Returns the copy of the frog
        """
        self._frog1 = Frog(self._xi, self._yi, hitboxjson)
        return self._frog1

    def checkFrogLives(self):
        """
        Returns True if the frog has life >= 1.
        """
        if len(self._lives) < 1:
            return False
        else:
            return True

    def minusFrogLives(self):
        """
        Decreases the frog's lives by 1.
        """
        del self._lives[-1]

    def frogNone(self):
        """
        Returns true if the frog is None
        """
        return self._frog.getSprite() == None

    def getWin(self):
        """
        Returns True if the frog has just won the game.
        """
        return self._frogwin

    def setWin(self,bool):
        """
        Sets the state of the frog winning or not.
        """
        self._frogwin = bool

    def checkWinFinish2(self):
        """
        Returns True if the frog has won.
        """
        if type(self._lanes[4]) == Hedge:
            return self._lanes[-1].checkWinFinish() and self._lanes[4].checkWinFinish()
        else:
            return self._lanes[-1].checkWinFinish()

    # INITIALIZER (standard form) TO CREATE THE FROG AND LANES
    def __init__(self, json, hitboxjson):
        """
        Initializes the level with lanes and the frog.
        """
        lanes = json["lanes"]
        self._lanes = []
        for count in range(len(lanes)):
            if lanes[count]["type"] == "grass":
                image = Grass(json, count, hitboxjson)
            elif lanes[count]["type"] == "road":
                image = Road(json, count, hitboxjson)
            elif lanes[count]["type"] == "water":
                image = Water(json, count, hitboxjson)
            elif lanes[count]["type"] == "hedge":
                image = Hedge(json, count, hitboxjson)
            self._lanes.append(image)

        self._xi = (json["start"][0]+0.5)*GRID_SIZE
        self._yi = (json["start"][1]+0.5)*GRID_SIZE
        self._frog = Frog(self._xi,self._yi, hitboxjson)

        self._lives =[]
        for i in range(3):
            fhead = GImage(width = GRID_SIZE, height = GRID_SIZE,
            top = (json["size"][1]+1)*GRID_SIZE,
            right = (json["size"][0]-i)*GRID_SIZE, source = FROG_HEAD)
            self._lives.append(fhead)

        self._livecount = GLabel(font_name = ALLOY_FONT, font_size = ALLOY_SMALL,
        right = self._lives[2].left, y = (json["size"][1]+0.5)*GRID_SIZE,
        text = "LIVES:", linecolor = "dark green")

        self._frogwin = False
        self._animator = None
        self._jumpsound = Sound(CROAK_SOUND)
        self._trillsound = Sound(TRILL_SOUND)
        self._splatsound = Sound(SPLAT_SOUND)

    # UPDATE METHOD TO MOVE THE FROG AND UPDATE ALL OF THE LANES
    def update(self,input,width,height,dt,hitboxjson):
        """
        Returns False when it the app should stop calling update.
        """
        if not self._animator is None:
            try:
                self._animator.send(dt)
            except:
                self._animator = None
        elif input.is_key_down('left') and not self.frogNone():
            self._helpUpdateLeft(dt)
        elif input.is_key_down('right') and not self.frogNone():
            self._helpUpdateRight(dt,width)
        elif input.is_key_down('up') and not self.frogNone():
            self._helpUpdateUp(dt,height)
        elif (self._animator ==  None and self._checkExit()
        and not self._checkOpenlog() and self._checkOnHedge()):
            self._helpUpdateWin()
        elif input.is_key_down('down') and not self.frogNone():
            self._helpUpdateDown(dt)

        self._helpUpdateCrash(dt,width)
        self._helpUpdateLog(dt,width)

    # DRAW METHOD TO DRAW THE FROG AND THE INDIVIDUAL LANES
    def draw(self,view):
        """
        Draw the lanes and the frog.
        """
        for count in range(len(self._lanes)):
            self._lanes[count].draw(view)

        for i in range(len(self._lives)):
            self._lives[i].draw(view)
        self._livecount.draw(view)

        if not self._frog == None:
            self._frog.draw(view)

    # ANY NECESSARY HELPERS (SHOULD BE HIDDEN)
    def _helpUpdateLeft(self,dt):
        """
        Helper method to update left press.
        """
        newpos = self._frog.getSprite().x - GRID_SIZE
        self._frog.getSprite().angle = FROG_WEST
        if newpos >= 0 and self._checkOnHedge() == False:
            self._jumpsound.play()
            self._animator = self._frog.coroutine_turn(dt,"left")
            next(self._animator)

    def _helpUpdateRight(self,dt,width):
        """
        Helper method to update right press.
        """
        newpos = self._frog.getSprite().x + GRID_SIZE
        self._frog.getSprite().angle = FROG_EAST
        if newpos <= width and self._checkOnHedge() == False:
            self._jumpsound.play()
            self._animator = self._frog.coroutine_turn(dt,"right")
            next(self._animator)

    def _helpUpdateUp(self,dt,height):
        """
        Helper method to update up press.
        """
        newpos = self._frog.getSprite().y + GRID_SIZE
        self._frog.getSprite().angle = FROG_NORTH
        if newpos <= (height-GRID_SIZE) and self._checkToHedge() == False:
            self._jumpsound.play()
            self._animator = self._frog.coroutine_slide(dt,"up")
            next(self._animator)
        if (newpos <= (height-GRID_SIZE) and self._checkToHedge()
            and self._checkOpenlog()):
            self._jumpsound.play()
            self._animator = self._frog.coroutine_slide(dt,"up")
            next(self._animator)
        if (newpos <= (height-GRID_SIZE) and self._checkToHedge()
            and self._checkExit()
            and self._lanes[-1].checkOpen(self._frog.getSprite().x,
            self._frog.getSprite().y+GRID_SIZE)):
            self._jumpsound.play()
            self._animator = self._frog.coroutine_slide(dt,"up")
            next(self._animator)
        if type(self._lanes[4]) == Hedge:
            if (newpos <= (height-GRID_SIZE) and self._checkToHedge()
            and self._lanes[4].checkOpen(self._frog.getSprite().x,
            self._frog.getSprite().y+GRID_SIZE)):
                self._jumpsound.play()
                self._animator = self._frog.coroutine_slide(dt,"up")
                next(self._animator)
            if self._checkOnHedge() and self._checkOpenlog():
                self._jumpsound.play()
                self._animator = self._frog.coroutine_slide(dt,"up")
                next(self._animator)

    def _helpUpdateDown(self,dt):
        """
        Helper method to update down press.
        """
        newpos = self._frog.getSprite().y-GRID_SIZE
        self._frog.getSprite().angle = FROG_SOUTH
        if newpos >= 0 and self._checkAboveHedge() == False:
            self._jumpsound.play()
            self._animator = self._frog.coroutine_slide(dt,"down")
            next(self._animator)
        if newpos >= 0 and self._checkAboveHedge() and self._checkOpenlog():
            self._jumpsound.play()
            self._animator = self._frog.coroutine_slide(dt,"down")
            next(self._animator)

    def _helpUpdateWin(self):
        """
        Helper method to update right press.
        """
        x = self._returnExit().x
        y = self._returnExit().y
        if self._returnHedge() == "middle hedge":
            self._trillsound.play()
            if self._lanes[4].addOccupy(x, y):
                self._frog.setSprite(None)
                self._frogwin = True
        elif self._returnHedge() == "final hedge":
            self._trillsound.play()
            if self._lanes[-1].addOccupy(x, y):
                self._frog.setSprite(None)
                self._frogwin = True

    def _helpUpdateCrash(self,dt,width):
        """
        Helper method to detect and update car crash.
        """
        for index in range(len(self._lanes)):
            self._lanes[index].update(dt,width)
            if type(self._lanes[index]) == Road:
                if (not self.frogNone()
                    and self._lanes[index].detectSquash(self._frog.getSprite())):
                    self._splatsound.play()
                    self._animator = None
                    self._frog.setSprite(None)

    def _helpUpdateLog(self,dt,width):
        """
        Helper method to update log situations.
        """
        for index in range(len(self._lanes)):
            if type(self._lanes[index]) == Water:
                if ((not self.frogNone()) and self._animator == None
                and self._lanes[index].checkOnWater(self._frog.getSprite())
                and (not self._lanes[index].checkOnLog(self._frog.getSprite().x,
                self._frog.getSprite().y))):
                    self._splatsound.play()
                    self._frog.setSprite(None)
                if ((not self.frogNone()) and self._animator == None
                and self._lanes[index].checkOnLog(self._frog.getSprite().x,
                self._frog.getSprite().y)):
                    self._frog.getSprite().x += dt * self._lanes[index].getWaterspeed()
                    if self._frog.getSprite().x > width or self._frog.getSprite().x < 0:
                        self._frog.setSprite(None)

    def _checkOnHedge(self):
        """
        Returns true if the frog overlaps with the hedge.
        """
        result1 = self._frog.getSprite().collides(self._lanes[-1].getTiles())
        result2 = False
        if type(self._lanes[4]) == Hedge:
            result2 = self._frog.getSprite().collides(self._lanes[4].getTiles())
        return result1 or result2

    def _returnHedge(self):
        """
        Returns the hedge the frog is on.
        """
        if self._frog.getSprite().collides(self._lanes[-1].getTiles()):
            return "final hedge"
        if (type(self._lanes[4]) == Hedge
            and self._frog.getSprite().collides(self._lanes[4].getTiles())):
            return "middle hedge"

    def _checkToHedge(self):
        """
        Returns true if the frog will overlap with the hedge.
        """
        result1 = (self._animator == None
        and self._frog.getSprite().collides(self._lanes[-2].getTiles()))
        result2 = False
        if type(self._lanes[4]) == Hedge:
            result2 = (self._animator == None
            and self._frog.getSprite().collides(self._lanes[3].getTiles()))
        return result1 or result2

    def _checkAboveHedge(self):
        """
        Returns true if the frog will overlap with the hedge.
        """
        result = False
        if type(self._lanes[4]) == Hedge:
            result = self._frog.getSprite().collides(self._lanes[5].getTiles())
        return result

    def _checkExit(self):
        """
        Returns True if the frog will overlap with the exit.
        """
        for count in range(len(self._lanes[-1].getExit())):
            if self._lanes[-1].getExit()[count].contains((self._frog.getSprite().x,
            self._frog.getSprite().y+GRID_SIZE)):
                return True
            elif self._lanes[-1].getExit()[count].contains((self._frog.getSprite().x,
            self._frog.getSprite().y)):
                return True

        if type(self._lanes[4]) == Hedge:
            for count in range(len(self._lanes[4].getExit())):
                if self._lanes[4].getExit()[count].contains((self._frog.getSprite().x,
                self._frog.getSprite().y+GRID_SIZE)):
                    return True
                elif self._lanes[4].getExit()[count].contains((self._frog.getSprite().x,
                self._frog.getSprite().y)):
                    return True

        return False

    def _checkOpenlog(self):
        """
        Returns True if the frog is on the open log.
        """
        if type(self._lanes[4]) == Hedge:
            if self._lanes[4].getExit()[1].contains((self._frog.getSprite().x,
            self._frog.getSprite().y+GRID_SIZE)):
                return True
            elif self._lanes[4].getExit()[1].contains((self._frog.getSprite().x,
            self._frog.getSprite().y)):
                return True
            elif self._lanes[4].getExit()[1].contains((self._frog.getSprite().x,
            self._frog.getSprite().y-GRID_SIZE)):
                return True
        else:
            return False

    def _returnExit(self):
        """
        Returns the exit object the frog is facing.
        """
        for count in range(len(self._lanes[-1].getExit())):
            if self._lanes[-1].getExit()[count].contains((self._frog.getSprite().x,
            self._frog.getSprite().y)):
                return self._lanes[-1].getExit()[count]

        if type(self._lanes[4]) == Hedge:
            if self._lanes[4].getExit()[0].contains((self._frog.getSprite().x,
            self._frog.getSprite().y)):
                return self._lanes[4].getExit()[0]
            elif self._lanes[4].getExit()[2].contains((self._frog.getSprite().x,
            self._frog.getSprite().y)):
                return self._lanes[4].getExit()[2]

        return None
