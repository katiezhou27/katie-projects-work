"""
Models module for Froggit

This module contains the model classes for the Frogger game. Anything that you
interact with on the screen is model: the frog, the cars, the logs, and so on.

Just because something is a model does not mean there has to be a special class for
it. Unless you need something special for your extra gameplay features, cars and logs
could just be an instance of GImage that you move across the screen. You only need a new
class when you add extra features to an object.

That is why this module contains the Frog class.  There is A LOT going on with the
frog, particularly once you start creating the animation coroutines.

If you are just working on the main assignment, you should not need any other classes
in this module. However, you might find yourself adding extra classes to add new
features.  For example, turtles that can submerge underneath the frog would probably
need a custom model for the same reason that the frog does.

If you are unsure about  whether to make a new class or not, please ask on Piazza. We
will answer.

# Katie (Erqi) Zhou, ez224
# Dec 21, 2020
"""
from consts import *
from game2d import *

# PRIMARY RULE: Models are not allowed to access anything in any module other than
# consts.py.  If you need extra information from a lane or level object, then it
# should be a parameter in your method.


class Frog(GImage):         # You will need to change this by Task 3
    """
    A class representing the frog

    The frog is represented as an image (or sprite if you are doing timed animation).
    However, unlike the obstacles, we cannot use a simple GImage class for the frog.
    The frog has to have additional attributes (which you will add).  That is why we
    make it a subclass of GImage.

    When you reach Task 3, you will discover that Frog needs to be a composite object,
    tracking both the frog animation and the death animation.  That will like caused
    major modifications to this class.
    """
    # LIST ALL HIDDEN ATTRIBUTES HERE
    # Attribute:_sprite
    # Invariant:_sprite is a GSprite object
    #
    # Attribute:_live
    # Invariant:_live is a bool

    # GETTERS AND SETTERS (ONLY ADD IF YOU NEED THEM)
    def getSprite(self):
        """
        Returns the sprite object.
        """
        return self._sprite

    def setSprite(self,set):
        """
        Sets the sprite object.
        """
        self._sprite = set


    # INITIALIZER TO SET FROG POSITION
    def __init__(self, x, y, hitboxjson):
        """
        Initializes the frog object.
        """
        super().__init__(x = x, y = y, source = FROG_IMAGE)
        self._live = True
        self.hitbox = hitboxjson["images"]["frog"]["hitbox"]
        hitboxs = hitboxjson["sprites"]["frog"]
        self._sprite = GSprite(x = x, y = y, source = FROG_SPRITE+".png",
        hitboxes = hitboxs["hitboxes"], format = hitboxs["format"],
        angle = FROG_NORTH)

    # ADDITIONAL METHODS (DRAWING, COLLISIONS, MOVEMENT, ETC
    def coroutine_turn(self,dt,direction):
        """
        Animates the frog movement to turn left or right.
        """
        sx = self._sprite.x
        if direction == "left":
            fx = sx - GRID_SIZE
        else:
            fx = sx + GRID_SIZE

        steps = (fx - sx)/FROG_SPEED
        animating = True
        POSITION_NEUTRAL = 0
        POSITION_FIRST = 4
        POSITION_LAST = 0

        while animating:
            dt = (yield)
            dis = dt * steps
            self._sprite.x += dis
            if abs(self._sprite.x - sx) >= GRID_SIZE:
                self._sprite.x = fx
                animating = False
            frac = 2*(self._sprite.x - sx)/(fx - sx)
            if frac < 1:
                frame = POSITION_NEUTRAL+frac*(POSITION_FIRST-POSITION_NEUTRAL)
                self._sprite.frame = round(frame)
            else:
                frac = frac-1
                frame = POSITION_FIRST+frac*(POSITION_LAST-POSITION_FIRST)
                self._sprite.frame = round(frame)

    def coroutine_slide(self,dt,direction):
        """
        Animates the frog movement to move up or down.
        """
        sy = self._sprite.y
        if direction == "up":
            fy = sy + GRID_SIZE
        else:
            fy = sy - GRID_SIZE

        steps = (fy - sy)/FROG_SPEED
        animating = True
        POSITION_NEUTRAL = 0
        POSITION_FIRST = 4
        POSITION_LAST = 0

        while animating:
            dt = (yield)
            dis = dt * steps
            self._sprite.y += dis

            if abs(self._sprite.y - sy) >= GRID_SIZE:
                self._sprite.y = fy
                animating = False
            frac = 2*(self._sprite.y - sy)/(fy - sy)
            if frac < 1:
                frame = POSITION_NEUTRAL+frac*(POSITION_FIRST-POSITION_NEUTRAL)
                self._sprite.frame = round(frame)
            else:
                frac = frac-1
                frame = POSITION_FIRST+frac*(POSITION_LAST-POSITION_FIRST)
                self._sprite.frame = round(frame)

    def draw(self,view):
        """
        Draws the frog movement.
        """
        if not self._sprite == None:
            self._sprite.draw(view)

# IF YOU NEED ADDITIONAL LANE CLASSES, THEY GO HERE
class Lane(object):
    """
    A composite object that contain the tiles as well as the obstacles.
    """
    # LIST ALL HIDDEN ATTRIBUTES HERE
    # Attribute:_tile
    # Invariant:_tile is a GTile object.
    #
    # Attribute:_objs
    # Invariant:_objs is a the list of objects in a line
    #
    # Attribute:_lanespeed
    # Invariant:_lanespeed is an int that represents the speed of the lane.

    #GETTERS AND SETTERS
    def getTiles(self):
        """
        Returns the tiles in the lane object.
        """
        return self._tile

    # INITIALIZER TO SET UP THE LANE
    def __init__(self, json, num, hitboxjson):
        """
        Initializes the lane object.
        """
        self._tile = GTile(bottom = GRID_SIZE*(num),left = 0,
        width = json["size"][0]*GRID_SIZE,height = GRID_SIZE,
        source = json["lanes"][num]["type"]+".png")

        self._objs = []
        lane = json["lanes"][num]
        if "objects" in lane:
            olist = lane["objects"]
            for count in range(len(olist)):
                hitbox = hitboxjson["images"][olist[count]["type"]]["hitbox"]
                image = GImage(y = self._tile.y,
                x = (olist[count]["position"]+0.5)*GRID_SIZE,
                source = olist[count]["type"]+".png", hitbox = hitbox)
                self._objs.append(image)

        self._lanespeed = 0
        if "speed" in lane:
            self._lanespeed = lane["speed"]
            if lane["speed"] < 0:
                for index in range(len(self._objs)):
                    self._objs[index].angle = 180

    #UPDATE METHOD
    def update(self,dt,width):
        """
        Update the movements of the obstacles on the lane.
        """
        for index in range(len(self._objs)):
            self._objs[index].x += dt*self._lanespeed
            if self._objs[index].x <= -2*GRID_SIZE:
                d = self._objs[index].x - (-2*GRID_SIZE)
                self._objs[index].x = width + 2*GRID_SIZE + d
            if self._objs[index].x >= width + 2*GRID_SIZE:
                d = self._objs[index].x - 2*GRID_SIZE - width
                self._objs[index].x = -(2*GRID_SIZE - d)

    #DRAW METHOD
    def draw(self,view):
        """
        Draws the lane.
        """
        self._tile.draw(view)

        for index in range(len(self._objs)):
            self._objs[index].draw(view)


class Grass(Lane):
    """
    A lane of the grass type. Subclass Lane class.
    """
    def __init__(self, json, num, hitboxjson):
        """
        Initializes the grass object.
        """
        super().__init__(json, num, hitboxjson)

class Road(Lane):
    """
    A lane of the road type. Subclass Lane class.
    """
    def __init__(self, json, num, hitboxjson):
        """
        Initizes the Road object.
        """
        super().__init__(json, num, hitboxjson)

    def detectSquash(self,frog):
        """
        Returns True if the frog has collided with a car.
        """
        sig = False
        for count in range(len(self._objs)):
            if self._objs[count].collides(frog):
                sig = True
        return sig


class Water(Lane):
    """
    A lane of the water type. Subclass Lane class.
    """
    #GETTERS AND SETTERs
    def checkOnLog(self,x,y):
        """
        Returns True if the frog is on top of a log in this lane.
        """
        for count in range(len(self._objs)) :
            if self._objs[count].contains((x,y)):
                return True
        return False

    def checkOnWater(self,obj):
        """
        Returns True if the frog is in the water lane.
        """
        if self._tile.collides(obj):
            return True
        else:
            return False

    def getWaterspeed(self):
        """
        Returns the speed of the water lane.
        """
        return self._lanespeed

    #INITIALIZER
    def __init__(self, json, num, hitboxjson):
        """
        Initizes the water object.
        """
        super().__init__(json, num, hitboxjson)


class Hedge(Lane):
    """
    A lane of the hedge type. Subclass Lane class.
    """
    # LIST ALL HIDDEN ATTRIBUTES HERE
    # Attribute:_open
    # Invariant:_open is a list of objects that resemble open spaces.
    #
    # Attribute:_occupied
    # Invariant:_occupied is a list of objects that resemble already won spaces.

    #GETTERS and SETTERS
    def getExit(self):
        """
        Returns all the exits or opens in the Hedge object.
        """
        return self._objs

    def getOpen(self):
        """
        Returns the open exits in the Hedge object.
        """
        return self._open

    def addOccupy(self,x,y):
        """
        Adds occupied spaces, updates the open space to occupy, and returns true
        when it finishes the update.
        """
        image = GImage(x = x, y = y, source = FROG_SAFE)
        self._occupied.append(image)
        for count in range(len(self._open)):
            if image.collides(self._open[count]):
                del self._open[count]
                return True

    def checkOpen(self, x, y):
        """
        Returns True if the exit is open to occupy.
        """
        for count in range(len(self._open)):
            if self._open[count].contains((x,y)):
                return True
        return False

    def checkWinFinish(self):
        """
        Returns True when there is no open space for another win.
        """
        return self._open == []

    def checkOnHedge(self,x,y):
        """
        Returns True if the point is on the hedge.
        """
        return self._tile.contains((x,y))

    #INITIALIZER
    def __init__(self, json, num, hitboxjson):
        """
        Initializes the Hedge object.
        """
        super().__init__(json, num, hitboxjson)
        self._occupied = []
        self._open = []
        lane = json["lanes"][num]
        olist = lane["objects"]
        for count in range(len(olist)):
            if olist[count]["type"] == "exit":
                image = GImage(y = self._tile.y,
                x = (olist[count]["position"]+0.5)*GRID_SIZE,
                source = olist[count]["type"]+".png")
                self._open.append(image)

    def draw(self,view):
        """
        Draws the hedge.
        """
        super().draw(view)
        if not self._occupied == []:
            for i in range(len(self._occupied)):
                self._occupied[i].draw(view)
